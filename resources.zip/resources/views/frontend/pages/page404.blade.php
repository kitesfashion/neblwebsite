@extends('frontend.master')

@section('mainContent')

<style type="text/css">
  
</style>
  <section class="section">
    <div class="container">
      <h3 class="card-title" style="text-align: center;font-size: 54px;color: #d41010;">Sorry !</h3>
      <h4 class="card-title" style="text-align: center;font-size: 30px;color: #e63030;">Page Not Found</h4>
    </div> 
  </section>
@endsection