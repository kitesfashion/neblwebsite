@extends('frontend.master')

@section('mainContent')
	@include('frontend.home.element.top_section')
	@include('frontend.home.element.welcome_section')
	@include('frontend.home.element.company_messege_section')
	@include('frontend.home.element.testimonial_section')

@endsection